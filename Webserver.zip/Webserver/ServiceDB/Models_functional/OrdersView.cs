﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ServiceDB.Models
{
    public partial class OrdersView
    {
    }
}
